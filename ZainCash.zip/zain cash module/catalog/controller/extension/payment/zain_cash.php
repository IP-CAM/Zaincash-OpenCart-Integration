<?php
class ControllerExtensionPaymentZainCash extends Controller {
	public function index() {
		
		$this->load->model('checkout/order');
		$this->load->model('localisation/country');
		$this->load->model('localisation/zone');
		
		$data['action'] = $this->url->link('extension/payment/zain_cash');
		
		$order_info = $this->model_checkout_order->getOrder($this->session->data['order_id']);
		
		$secret_key = $this->config->get('zain_cash_secret');
		$key = $this->config->get('zain_cash_secret');
		$msisdn = $this->config->get('zain_cash_msisdn'); //wallent number
		$total = $order_info['total']; //order total
		$product_name = "test";		//service type
		$redirect_url = $this->url->link('extension/payment/zain_cash');
		$test_mode = $this->config->get('zain_cash_test');
		if($test_mode == '1')
		{
			$test_mode_action = 'test';
		}
		else
		{
			$test_mode_action = 'live';
		}
		
		$data_array = array(
					'amount' => $total,
					'serviceType'	=> $product_name,
					'msisdn'	=> $msisdn,
					'redirectUrl'	=> $redirect_url
					);
		$zaincash = new zaincashwt($data_array,$secret_key);
		$response = $zaincash->sendData($key,$secret_key,$test_mode);
		

		$secure_token_id = md5($this->session->data['order_id'] . mt_rand() . microtime());

		//$this->model_extension_payment_pp_payflow_iframe->addOrder($order_info['order_id'], $secure_token_id);

		$shipping_country = $this->model_localisation_country->getCountry($order_info['shipping_country_id']);
		$shipping_zone = $this->model_localisation_zone->getZone($order_info['shipping_zone_id']);

		$payment_country = $this->model_localisation_country->getCountry($order_info['payment_country_id']);
		$payment_zone = $this->model_localisation_zone->getZone($order_info['payment_zone_id']);

		if ($shipping_country) {
			$url_params['SHIPTOFIRSTNAME'] = $order_info['shipping_firstname'];
			$url_params['SHIPTOLASTNAME'] = $order_info['shipping_lastname'];
			$url_params['SHIPTOSTREET'] = trim($order_info['shipping_address_1'] . ' ' . $order_info['shipping_address_2']);
			$url_params['SHIPTOCITY'] = $order_info['shipping_city'];
			$url_params['SHIPTOSTATE'] = $shipping_zone['code'];
			$url_params['SHIPTOZIP'] = $order_info['shipping_postcode'];
			$url_params['SHIPTOCOUNTRY'] = $shipping_country['iso_code_2'];
		}

		
		$data['button_confirm'] = $this->language->get('button_confirm');

		return $this->load->view('extension/payment/zain_cash', $data);
	}
}