<?php
// Text
$_['text_title']	= 'Zain Cash';
$_['text_testmode']	= 'Warning: The payment gateway is in \'test Mode\'. Your account will not be charged.';
$_['text_total']	= 'Shipping, Handling, Discounts & Taxes';