<?php
class ControllerExtensionPaymentZainCash extends Controller {
	private $error = array();

	public function index() {
		$this->load->language('extension/payment/zain_cash');

		$this->document->setTitle($this->language->get('heading_title'));

		$this->load->model('setting/setting');

		if (($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validate()) {
			$this->model_setting_setting->editSetting('zain_cash', $this->request->post);

			$this->session->data['success'] = $this->language->get('text_success');

			$this->response->redirect($this->url->link('extension/extension', 'token=' . $this->session->data['token'] . '&type=payment', true));
		}

		$data['heading_title'] = $this->language->get('heading_title');

		$data['text_edit'] = $this->language->get('text_edit');
		$data['text_enabled'] = $this->language->get('text_enabled');
		$data['text_disabled'] = $this->language->get('text_disabled');
		$data['text_all_zones'] = $this->language->get('text_all_zones');
		$data['text_yes'] = $this->language->get('text_yes');
		$data['text_no'] = $this->language->get('text_no');
		$data['text_authorization'] = $this->language->get('text_authorization');
		$data['text_sale'] = $this->language->get('text_sale');
		$data['text_iframe'] = $this->language->get('text_iframe');
		$data['text_redirect'] = $this->language->get('text_redirect');

		$data['entry_key'] = $this->language->get('entry_key');
		$data['entry_name'] = $this->language->get('entry_name');
		$data['entry_msisdn'] = $this->language->get('entry_msisdn');
		$data['entry_secret'] = $this->language->get('entry_secret');
		$data['entry_test'] = $this->language->get('entry_test');
		$data['entry_debug'] = $this->language->get('entry_debug');
		$data['entry_currency'] = $this->language->get('entry_currency');
		$data['entry_status'] = $this->language->get('entry_status');
		$data['entry_cancel_url'] = $this->language->get('entry_cancel_url');
		$data['entry_error_url'] = $this->language->get('entry_error_url');
		$data['entry_return_url'] = $this->language->get('entry_return_url');
		$data['entry_post_url'] = $this->language->get('entry_post_url');
		$data['entry_order_status'] = $this->language->get('entry_order_status');

		$data['help_key'] = $this->language->get('help_key');
		$data['help_name'] = $this->language->get('help_name');
		$data['help_msisdn'] = $this->language->get('help_msisdn');
		$data['help_debug'] = $this->language->get('help_debug');
		$data['help_test'] = $this->language->get('help_test');
		$data['help_secret'] = $this->language->get('help_secret');

		$data['tab_settings'] = $this->language->get('tab_settings');
		$data['tab_order_status'] = $this->language->get('tab_order_status');
		$data['tab_checkout_customisation'] = $this->language->get('tab_checkout_customisation');

		$data['button_save'] = $this->language->get('button_save');
		$data['button_cancel'] = $this->language->get('button_cancel');

		if (isset($this->error['warning'])) {
			$data['error_warning'] = $this->error['warning'];
		} else {
			$data['error_warning'] = '';
		}

		if (isset($this->error['key'])) {
			$data['error_key'] = $this->error['key'];
		} else {
			$data['error_key'] = '';
		}

		if (isset($this->error['name'])) {
			$data['error_name'] = $this->error['name'];
		} else {
			$data['error_name'] = '';
		}

		if (isset($this->error['msisdn'])) {
			$data['error_msisdn'] = $this->error['msisdn'];
		} else {
			$data['error_msisdn'] = '';
		} 

		if (isset($this->error['secret'])) {
			$data['error_secret'] = $this->error['secret'];
		} else {
			$data['error_secret'] = '';
		}

		$data['breadcrumbs'] = array();

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_home'),
			'href' => $this->url->link('common/dashboard', 'token=' . $this->session->data['token'], true),
		);

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_zaincash'),
			'href' => $this->url->link('extension/extension', 'token=' . $this->session->data['token'] . '&type=payment', true),
		);

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('heading_title'),
			'href' => $this->url->link('extension/payment/zain_cash', 'token=' . $this->session->data['token'], true),
		);

		$data['action'] = $this->url->link('extension/payment/zain_cash', 'token=' . $this->session->data['token'], true);

		$data['cancel'] = $this->url->link('extension/extension', 'token=' . $this->session->data['token'] . '&type=payment', true);

		if (isset($this->request->post['zain_cash_key'])) {
			$data['zain_cash_key'] = $this->request->post['zain_cash_key'];
		} else {
			$data['zain_cash_key'] = $this->config->get('zain_cash_key');
		}

		if (isset($this->request->post['zain_cash_name'])) {
			$data['zain_cash_name'] = $this->request->post['zain_cash_name'];
		} else {
			$data['zain_cash_name'] = $this->config->get('zain_cash_name');
		}

		if (isset($this->request->post['zain_cash_msisdn'])) {
			$data['zain_cash_msisdn'] = $this->request->post['zain_cash_msisdn'];
		} else {
			$data['zain_cash_msisdn'] = $this->config->get('zain_cash_msisdn');
		} 

		if (isset($this->request->post['zain_cash_secret'])) {
			$data['zain_cash_secret'] = $this->request->post['zain_cash_secret'];
		} else {
			$data['zain_cash_secret'] = $this->config->get('zain_cash_secret');
		}

		/* if (isset($this->request->post['zain_cash_currency'])) {
			$data['zain_cash_currency'] = $this->request->post['zain_cash_currency'];
		} else {
			$data['zain_cash_currency'] = $this->config->get('zain_cash_currency');
		} */

		if (isset($this->request->post['zain_cash_test'])) {
			$data['zain_cash_test'] = $this->request->post['zain_cash_test'];
		} else {
			$data['zain_cash_test'] = $this->config->get('zain_cash_test');
		}

		$this->load->model('localisation/order_status');

		$data['order_statuses'] = $this->model_localisation_order_status->getOrderStatuses();

		if (isset($this->request->post['zain_cash_order_status_id'])) {
			$data['zain_cash_order_status_id'] = $this->request->post['zain_cash_order_status_id'];
		} else {
			$data['zain_cash_order_status_id'] = $this->config->get('zain_cash_order_status_id');
		}

		if (isset($this->request->post['zain_cash_status'])) {
			$data['zain_cash_status'] = $this->request->post['zain_cash_status'];
		} else {
			$data['zain_cash_status'] = $this->config->get('zain_cash_status');
		}

		if (isset($this->request->post['zain_cash_debug'])) {
			$data['zain_cash_debug'] = $this->request->post['zain_cash_debug'];
		} else {
			$data['zain_cash_debug'] = $this->config->get('zain_cash_debug');
		}

		/* $data['post_url'] = HTTPS_CATALOG . 'index.php?route=extension/payment/zain_cash/paymentipn';
		$data['cancel_url'] = HTTPS_CATALOG . 'index.php?route=extension/payment/zain_cash/paymentcancel';
		$data['error_url'] = HTTPS_CATALOG . 'index.php?route=extension/payment/zain_cash/paymenterror'; */
		$data['return_url'] = HTTPS_CATALOG . 'index.php?route=extension/payment/zain_cash/paymentreturn';

		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');

		$this->response->setOutput($this->load->view('extension/payment/zain_cash', $data));
	}

	/* public function install() {
		$this->load->model('extension/payment/zain_cash');

		$this->model_extension_payment_zain_cash->install();
	}

	public function uninstall() {
		$this->load->model('extension/payment/zain_cash');

		$this->model_extension_payment_zain_cash->uninstall();
	}

	public function refund() {
		$this->load->model('extension/payment/zain_cash');
		$this->load->model('sale/order');
		$this->load->language('extension/payment/zain_cash');

		$transaction = $this->model_extension_payment_zain_cash->getTransaction($this->request->get['transaction_reference']);

		if ($transaction) {
			$this->document->setTitle($this->language->get('heading_refund'));

			$data['breadcrumbs'] = array();

			$data['breadcrumbs'][] = array(
				'text' => $this->language->get('text_home'),
				'href' => $this->url->link('common/dashboard', 'token=' . $this->session->data['token'], true)
			);

			$data['breadcrumbs'][] = array(
				'text' => $this->language->get('text_extension'),
				'href' => $this->url->link('extension/extension', 'token=' . $this->session->data['token'], true)
			);

			$data['breadcrumbs'][] = array(
				'text' => $this->language->get('heading_title'),
				'href' => $this->url->link('extension/payment/zain_cash', 'token=' . $this->session->data['token'], true)
			);

			$data['breadcrumbs'][] = array(
				'text' => $this->language->get('heading_refund'),
				'href' => $this->url->link('extension/payment/zain_cash/refund', 'transaction_reference=' . $this->request->get['transaction_reference'] . '&token=' . $this->session->data['token'], true)
			);

			$data['transaction_reference'] = $transaction['transaction_reference'];
			$data['transaction_amount'] = number_format($transaction['amount'], 2);
			$data['cancel'] = $this->url->link('sale/order/info', 'token=' . $this->session->data['token'] . '&order_id=' . $transaction['order_id'], true);

			$data['token'] = $this->session->data['token'];

			$data['heading_refund'] = $this->language->get('heading_refund');

			$data['entry_transaction_reference'] = $this->language->get('entry_transaction_reference');
			$data['entry_transaction_amount'] = $this->language->get('entry_transaction_amount');
			$data['entry_refund_amount'] = $this->language->get('entry_refund_amount');

			$data['button_cancel'] = $this->language->get('button_cancel');
			$data['button_refund'] = $this->language->get('button_refund');

			$data['header'] = $this->load->controller('common/header');
			$data['column_left'] = $this->load->controller('common/column_left');
			$data['footer'] = $this->load->controller('common/footer');

			$this->response->setOutput($this->load->view('extension/payment/zain_cash_refund', $data));
		} else {
			return $this->forward('error/not_found');
		}
	}

	public function doRefund() {
		$this->load->model('extension/payment/zain_cash');
		$this->load->language('extension/payment/zain_cash');
		$json = array();

		if (isset($this->request->post['transaction_reference']) && isset($this->request->post['amount'])) {

			$transaction = $this->model_extension_payment_zain_cash->getTransaction($this->request->post['transaction_reference']);

			if ($transaction) {
				$call_data = array(
					'TRXTYPE' => 'C',
					'TENDER'  => 'C',
					'ORIGID'  => $transaction['transaction_reference'],
					'AMT'     => $this->request->post['amount'],
				);

				$result = $this->model_extension_payment_zain_cash->call($call_data);

				if ($result['RESULT'] == 0) {
					$json['success'] = $this->language->get('text_refund_issued');

					$data = array(
						'order_id' => $transaction['order_id'],
						'type' => 'C',
						'transaction_reference' => $result['PNREF'],
						'amount' => $this->request->post['amount'],
					);

					$this->model_extension_payment_zain_cash->addTransaction($data);
				} else {
					$json['error'] = $result['RESPMSG'];
				}
			} else {
				$json['error'] = $this->language->get('error_missing_order');
			}
		} else {
			$json['error'] = $this->language->get('error_missing_data');
		}

		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($json));
	}

	public function capture() {
		$this->load->model('extension/payment/zain_cash');
		$this->load->model('sale/order');
		$this->load->language('extension/payment/zain_cash');

		if (isset($this->request->post['order_id']) && isset($this->request->post['amount']) && isset($this->request->post['complete'])) {
			$order_id = $this->request->post['order_id'];
			$paypal_order = $this->model_extension_payment_zain_cash->getOrder($order_id);
			$paypal_transactions = $this->model_extension_payment_zain_cash->getTransactions($order_id);
			$order_info = $this->model_sale_order->getOrder($order_id);

			if ($paypal_order && $order_info) {
				if ($this->request->post['complete'] == 1) {
					$complete = 'Y';
				} else {
					$complete = 'N';
				}

				$call_data = array(
					'TRXTYPE'         => 'D',
					'TENDER'          => 'C',
					'ORIGID'          => $paypal_order['transaction_reference'],
					'AMT'             => $this->request->post['amount'],
					'CAPTURECOMPLETE' => $complete
				);

				$result = $this->model_extension_payment_zain_cash->call($call_data);

				if ($result['RESULT'] == 0) {

					$data = array(
						'order_id'              => $order_id,
						'type'                  => 'D',
						'transaction_reference' => $result['PNREF'],
						'amount'                => $this->request->post['amount']
					);

					$this->model_extension_payment_zain_cash->addTransaction($data);
					$this->model_extension_payment_zain_cash->updateOrderStatus($order_id, $this->request->post['complete']);

					$actions = array();

					$actions[] = array(
						'title' => $this->language->get('text_capture'),
						'href' => $this->url->link('extension/payment/zain_cash/refund', 'transaction_reference=' . $result['PNREF'] . '&token=' . $this->session->data['token'], true),
					);

					$json['success'] = array(
						'transaction_type' => $this->language->get('text_capture'),
						'transaction_reference' => $result['PNREF'],
						'time' => date('Y-m-d H:i:s'),
						'amount' => number_format($this->request->post['amount'], 2),
						'actions' => $actions,
					);
				} else {
					$json['error'] = $result['RESPMSG'];
				}
			} else {
				$json['error'] = $this->language->get('error_missing_order');
			}
		} else {
			$json['error'] = $this->language->get('error_missing_data');
		}

		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($json));
	}

	public function void() {
		$this->load->model('extension/payment/zain_cash');
		$this->load->language('extension/payment/zain_cash');

		if (isset($this->request->post['order_id']) && $this->request->post['order_id'] != '') {
			$order_id = $this->request->post['order_id'];
			$paypal_order = $this->model_extension_payment_zain_cash->getOrder($order_id);

			if ($paypal_order) {
				$call_data = array(
					'TRXTYPE' => 'V',
					'TENDER' => 'C',
					'ORIGID' => $paypal_order['transaction_reference'],
				);

				$result = $this->model_extension_payment_zain_cash->call($call_data);

				if ($result['RESULT'] == 0) {
					$json['success'] = $this->language->get('text_void_success');
					$this->model_extension_payment_zain_cash->updateOrderStatus($order_id, 1);

					$data = array(
						'order_id' => $order_id,
						'type' => 'V',
						'transaction_reference' => $result['PNREF'],
						'amount' => '',
					);

					$this->model_extension_payment_zain_cash->addTransaction($data);
					$this->model_extension_payment_zain_cash->updateOrderStatus($order_id, 1);

					$json['success'] = array(
						'transaction_type' => $this->language->get('text_void'),
						'transaction_reference' => $result['PNREF'],
						'time' => date('Y-m-d H:i:s'),
						'amount' => '0.00',
					);
				} else {
					$json['error'] = $result['RESPMSG'];
				}
			} else {
				$json['error'] = $this->language->get('error_missing_order');
			}
		} else {
			$json['error'] = $this->language->get('error_missing_data');
		}

		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($json));
	}

	public function order() {
		$this->load->model('extension/payment/zain_cash');
		$this->load->language('extension/payment/zain_cash');

		$order_id = $this->request->get['order_id'];

		$paypal_order = $this->model_extension_payment_zain_cash->getOrder($order_id);

		if ($paypal_order) {
			$data['entry_capture_status'] = $this->language->get('entry_capture_status');
			$data['entry_captured_amount'] = $this->language->get('entry_captured_amount');
			$data['entry_capture'] = $this->language->get('entry_capture');
			$data['entry_void'] = $this->language->get('entry_void');
			$data['entry_transactions'] = $this->language->get('entry_transactions');
			$data['entry_complete_capture'] = $this->language->get('entry_complete_capture');

			$data['text_payment_info'] = $this->language->get('text_payment_info');
			$data['text_complete'] = $this->language->get('text_complete');
			$data['text_incomplete'] = $this->language->get('text_incomplete');
			$data['text_confirm_void'] = $this->language->get('text_confirm_void');

			$data['column_transaction_id'] = $this->language->get('column_transaction_id');
			$data['column_transaction_type'] = $this->language->get('column_transaction_type');
			$data['column_amount'] = $this->language->get('column_amount');
			$data['column_time'] = $this->language->get('column_time');
			$data['column_actions'] = $this->language->get('column_actions');

			$data['button_capture'] = $this->language->get('button_capture');
			$data['button_void'] = $this->language->get('button_void');

			$data['complete'] = $paypal_order['complete'];
			$data['order_id'] = $this->request->get['order_id'];
			$data['token'] = $this->request->get['token'];

			$data['transactions'] = array();

			$transactions = $this->model_extension_payment_zain_cash->getTransactions($order_id);

			foreach ($transactions as $transaction) {
				$actions = array();

				switch ($transaction['transaction_type']) {
					case 'V':
						$transaction_type = $this->language->get('text_void');
						break;
					case 'S':
						$transaction_type = $this->language->get('text_sale');

						$actions[] = array(
							'title' => $this->language->get('text_refund'),
							'href' => $this->url->link('extension/payment/zain_cash/refund', 'transaction_reference=' . $transaction['transaction_reference'] . '&token=' . $this->session->data['token'], true),
						);
						break;
					case 'D':
						$transaction_type = $this->language->get('text_capture');

						$actions[] = array(
							'title' => $this->language->get('text_refund'),
							'href' => $this->url->link('extension/payment/zain_cash/refund', 'transaction_reference=' . $transaction['transaction_reference'] . '&token=' . $this->session->data['token'], true),
						);
						break;
					case 'A':
						$transaction_type = $this->language->get('text_authorise');
						break;

					case 'C':
						$transaction_type = $this->language->get('text_refund');#
						break;

					default:
						$transaction_type = '';
						break;
				}

				$data['transactions'][] = array(
					'transaction_reference' => $transaction['transaction_reference'],
					'transaction_type'      => $transaction_type,
					'time'                  => $transaction['time'],
					'amount'                => $transaction['amount'],
					'actions'               => $actions
				);
			}

			return $this->load->view('extension/payment/zain_cash_order', $data);
		}
	} */

	protected function validate() {
		if (!$this->user->hasPermission('modify', 'extension/payment/zain_cash')) {
			$this->error['warning'] = $this->language->get('error_permission');
		}

		if (!$this->request->post['zain_cash_key']) {
			$this->error['key'] = $this->language->get('error_key');
		}

		if (!$this->request->post['zain_cash_name']) {
			$this->error['name'] = $this->language->get('error_name');
		}

		if (!$this->request->post['zain_cash_msisdn']) {
			$this->error['msisdn'] = $this->language->get('error_msisdn');
		}

		if (!$this->request->post['zain_cash_secret']) {
			$this->error['secret'] = $this->language->get('error_secret');
		}

		return !$this->error;
	}
}
