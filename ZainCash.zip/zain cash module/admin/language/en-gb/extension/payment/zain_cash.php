<?php
// Heading
$_['heading_title']					 = 'Zain Cash';
$_['heading_refund']				 = 'Refund';

// Text
$_['text_extension']				 = 'Extensions';
$_['text_success']					 = 'Success: You have modified Zain Cash account details!';
$_['text_edit']                      = 'Edit Zain Cash';
$_['text_zain_cash']		 = '<a target="_BLANK" href="https://api.zaincash.iq">
<img src="https://test.zaincash.iq/images/zaincash-ar.png" width="25%" height="51%" alt="Zain Cash" title="Zain Cash" style="border: 1px solid #EEEEEE;" /></a>';
$_['text_authorization']			 = 'Authorization';
$_['text_sale']						 = 'Sale';
$_['text_authorise']				 = 'Authorise';
$_['text_capture']					 = 'Delayed Capture';
$_['text_void']						 = 'Void';
$_['text_payment_info']				 = 'Payment information';
$_['text_complete']					 = 'Complete';
$_['text_incomplete']				 = 'Incomplete';
$_['text_transaction']				 = 'Transaction';
$_['text_confirm_void']				 = 'If you void you cannot capture any further funds';
$_['text_refund']					 = 'Refund';
$_['text_refund_issued']			 = 'Refund was issued successfully';
$_['text_redirect']					 = 'Redirect';
$_['text_iframe']					 = 'Iframe';
$_['help_checkout_method']			 = 'Please use Redirect method if do not have SSL installed or if you do not have Pay with PayPal option disabled on your hosted payment page.';
$_['text_zaincash']					 = 'Zain Cash Extension';

// Column
$_['column_transaction_id']			 = 'Transaction ID';
$_['column_transaction_type']		 = 'Transaction Type';
$_['column_amount']					 = 'Amount';
$_['column_time']					 = 'Time';
$_['column_actions']				 = 'Actions';

// Tab
$_['tab_settings']					 = 'Settings';
$_['tab_order_status']				 = 'Order Status';
$_['tab_checkout_customisation']	 = 'Checkout Customisation';

// Entry
$_['entry_key']					 	 = 'Key';
$_['entry_name']					 = 'Name';
$_['entry_msisdn']				 	 = 'MSISDN';
$_['entry_secret']					 = 'Secret';
$_['entry_test']					 = 'Test Mode';
$_['entry_currency']				 = 'Currency';
$_['entry_transaction']				 = 'Transaction Method';
$_['entry_order_status']			 = 'Order Status';
$_['entry_status']					 = 'Status';
$_['entry_transaction_id']			 = 'Transaction ID';
$_['entry_full_refund']				 = 'Full refund';
$_['entry_amount']					 = 'Amount';
$_['entry_message']					 = 'Message';
$_['entry_ipn_url']					 = 'IPN URL';
$_['entry_checkout_method']			 = 'Checkout Method';
$_['entry_debug']					 = 'Debug mode';
$_['entry_transaction_reference']	 = 'Transaction Reference';
$_['entry_transaction_amount']		 = 'Transaction Amount';
$_['entry_refund_amount']			 = 'Refund Amount';
$_['entry_capture_status']			 = 'Capture Status';
$_['entry_void']					 = 'Void';
$_['entry_capture']					 = 'Capture';
$_['entry_transactions']			 = 'Transactions';
$_['entry_complete_capture']		 = 'Complete Capture';
$_['entry_canceled_reversal_status'] = 'Canceled Reversal Status:';
$_['entry_completed_status']		 = 'Completed Status:';
$_['entry_denied_status']			 = 'Denied Status:';
$_['entry_expired_status']			 = 'Expired Status:';
$_['entry_failed_status']			 = 'Failed Status:';
$_['entry_pending_status']			 = 'Pending Status:';
$_['entry_processed_status']		 = 'Processed Status:';
$_['entry_refunded_status']			 = 'Refunded Status:';
$_['entry_reversed_status']			 = 'Reversed Status:';
$_['entry_voided_status']			 = 'Voided Status:';
$_['entry_cancel_url']				 = 'Cancel URL:';
$_['entry_error_url']				 = 'Error URL:';
$_['entry_return_url']				 = 'Return URL:';
$_['entry_post_url']				 = 'Silent POST URL:';

// Help
$_['help_key']					 = 'Your merchant login ID that you created when you registered for the Website Payments account';
$_['help_name']						 = 'Payment Account Name';
$_['help_msisdn']					 = 'MSISDN Number for the account';
$_['help_secret']					 = 'The ID provided to you by the authorised PayPal Reseller who registered you for the Payflow SDK. If you purchased your account directly from PayPal, use the PayPal Pro instead';
$_['help_test']						 = 'Use the live or testing (sandbox) gateway server to process transactions?';
$_['help_debug']					 = 'Logs additional information';

// Button
$_['button_refund']					 = 'Refund';
$_['button_void']					 = 'Void';
$_['button_capture']				 = 'Capture';

// Error
$_['error_permission']				 = 'Warning: You do not have permission to modify payment PayPal Website Payment Pro iFrame (UK)!';
$_['error_key']					 = 'Key Required!';
$_['error_name']					 = 'Name Required!';
$_['error_msisdn']				 = 'MSISDN Number Required!';
$_['error_secret']					 = 'Secret Key Required!';
$_['error_missing_data']			 = 'Missing data';
$_['error_missing_order']			 = 'Could not find the order';
$_['error_general']					 = 'There was an error';
$_['error_capture']				     = 'Enter an amount to capture';